CREATE DATABASE auto;
USE auto;
CREATE TABLE autos 
(
auto_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
make VARCHAR(128),
model VARCHAR(128),
year INTEGER,
mileage INTEGER
)
ENGINE=InnoDB CHARSET=utf8;
CREATE USER 'umsi@umich.edu' IDENTIFIED BY 'php123' ;
GRANT ALL PRIVILEGES ON auto.* TO 'umsi@umich.edu';
ALTER USER 'umsi@umich.edu' IDENTIFIED WITH mysql_native_password
BY 'php123';