<?php   
    require_once 'pdo.php';
    session_start();


?>

<html>
    <head>
        <title>Auto Database 5</title>
        <meta charset='utf-8'>
    </head>
    <body>
        <h1>Welcome bij Auto Database</h1>
        <a href='login.php'>Please login</a>

    </body>
</html>
