<?php
    require_once 'pdo.php';
    session_start();



    if ( isset ($_POST['account']) && isset ($_POST['password'])) {
        unset($_SESSION['account']);

        if ( empty($_POST['account']) || empty($_POST['password'])) {
            $_SESSION['error'] = "Email and password are required";
            header("Location:login.php");
            return;
        } 
        if ( preg_match('/@/', $_POST['account'] ) < 1) {
            $_SESSION['error'] = "Email must have an at-sign (@)";
            header("Location: login.php");
            return;                  
        } 

        if ( $_POST['password'] == 'php123' && $_POST['account'] == 'umsi@umich.edu' ) {
            $_SESSION['account'] = $_POST['account'];
            $_SESSION['success'] = 'Logged in';
            header('Location:view.php');
            return;
        }

        else {
            $_SESSION['error'] = 'Incorrect password';
            header('Location:login.php');
            return;
        }
    }
?>

<html>
    <head>
        <title>Auto Database Login</title>
    </head>
    <body>
        <h1>Please Login</h1>
        <?php   
            if ( isset ($_SESSION['error'])) {
                echo('<p style="color:red">'.$_SESSION['error'].'</p><br>');
                unset($_SESSION['error']);
            }
            if ( isset ($_SESSION['success'])) {
                echo('<p style="color:green">'.$_SESSION['success'].'</p><br>');
                unset($_SESSION['success']);
            }
        ?>
        <form method='post'>
            <p>Account: <input type='text' name='account' ></p>
            <p>Password: <input type='text' name='password' ></p>
            <p><input type='submit' value='Login'>
            <a href='logout.php'>Logout</a>
            </p>
        </form>
    </body>
</html>
