<?php
    session_start();
    $host = 'localhost';
    $username = 'root';
    $password = '';
    $database = 'test';
    $message = '';

    try {
        $connect = new PDO('mysql:host=$host;dbname=$database', $username, $password); 
        $connect->setAttribute(PDO::ATTR_ERRMODE PDO::ERRMODE_EXCEPTION);

        if ( isset($_POST['login'])) {
            if ( empty($_POST['username']) || empty($_POST['password'])) {
                $message = 'All fields are required';
            }
            else {
                $sql = 'SELECT * FROM users WHERE username = :username AND password = :password';
                $stmt = $connect->prepare($sql);
                $stmt->execute(array(
                    ':username' => $_POST['username'],
                    ':password' => $_POST['password']
                ));
                $count = $stmt->rowCount();
                if ($count > 0) {
                    $_SESSION['username'] = $_POST[ 'username'];
                    header('Location:view.php');
                } 
                else {
                    $message = 'Wrong data';
                }
            }
        }
    }
    catch(PDOException $error) {
        $message= $error->getMessage
    }
?>
<html>
    <head>
        <title>Online Login</title>
        <meta charset='utf-8'>
    </head>
    <body>
        <h1>Login SQL online</h1>
        <?php
            if ( isset($message)) {
                echo $message; 
            }
        ?>
        <form method='post'>
            <p>Username: <input type='text' name='username'></p>
            <p>Password: <input type='password' name='password'></p>
        </form>
    </body>
</html>
    
